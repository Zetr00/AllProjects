package com.example.petportal;

import java.io.Serializable;

public class Status implements Serializable {
    public int idStatus;
    public String nameStatus;
    public boolean isDeleted;
}
