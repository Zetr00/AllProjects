package com.example.petportal;

import java.io.Serializable;

public class Reason implements Serializable {
    public int idReason;
    public String nameReason;
    public boolean isDeleted;
}
