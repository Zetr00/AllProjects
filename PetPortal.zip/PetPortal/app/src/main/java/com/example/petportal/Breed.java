package com.example.petportal;

public class Breed {
    public int idBreed;
    public String nameBreed;
    public boolean isDeleted;
}
