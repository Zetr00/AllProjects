package com.example.petportal;

import java.io.Serializable;

public class Type implements Serializable {
    public int idType;
    public String nameType;
    public boolean isDeleted;
}
